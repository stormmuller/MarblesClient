﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Zenject.Tests.SceneDecorators
{
    public class Foo : MonoBehaviour
    {
    }
}

